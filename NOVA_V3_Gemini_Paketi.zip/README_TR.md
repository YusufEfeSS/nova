# NOVA V3 — Gemini AI + dosya yükleme

Bu paket iki parçadan oluşur:
- `index.html`: GitHub Pages arayüzü.
- `worker.js`: Gemini API anahtarını sunucu tarafında gizleyen Cloudflare Worker.

## 0. Önce sızan anahtarı iptal et
Sohbette veya başka bir herkese açık yerde paylaştığın anahtarı Google AI Studio / Google Cloud üzerinden devre dışı bırak. Yeni anahtarı sohbetlere veya GitHub'a koyma.

## 1. Cloudflare Worker oluştur (telefondan)
1. Cloudflare hesabında Workers & Pages bölümüne gir.
2. Yeni bir Worker oluştur ve `worker.js` içeriğini Worker kod editörüne yapıştır.
3. Deploy et.
4. Worker ayarlarında **Settings → Variables and Secrets** bölümünü aç.
5. `GEMINI_API_KEY` adlı bir **Secret** ekle ve yeni Gemini anahtarını değer olarak gir. Secret değerini kod içine yazma.
6. Deploy işlemini tekrar uygula. Worker adresin `https://...workers.dev` biçiminde olur.

Model adı kodda `gemini-3.8-flash` olarak ayarlı. Hesabında bu model kullanılamıyorsa, erişimin olan güncel bir Gemini Flash model kimliğiyle `worker.js` içindeki `MODEL` değerini değiştir.

## 2. GitHub Pages'e yükle
1. GitHub'da `nova-site` deponu aç.
2. `index.html` dosyasını yeni sürümle değiştir (Add file → Upload files → Commit changes).
3. Settings → Pages'te `main` ve `/(root)` seçili olsun.
4. Yayındaki siteni aç. Sol taraftaki “Güvenli Worker adresin” alanına Worker URL'sini yaz ve “ADRESİ KULLAN” düğmesine bas.

## 3. Dosya ekleri
Sohbette dosya ekle düğmesiyle TXT, MD, CSV, JSON, PDF, PNG, JPG/JPEG veya WEBP seçebilirsin. Bu örnekte bir seferde bir dosya, en fazla 7 MB kabul edilir. Dosya içeriği Gemini'ye gönderilir; gizli/kişisel belgeleri yükleme.

## Güvenlik ve kullanım
- API anahtarı yalnızca Cloudflare Worker Secret olarak saklanır.
- `worker.js` dosyasına gerçek API anahtarını yazma.
- Örnek CORS kodu geliştirme kolaylığı için `*` kullanıyor. Herkese açık siteyi büyütürken `worker.js` içindeki `cors()` fonksiyonunda izin verilen kaynağı kendi GitHub Pages alanınla sınırla.
- Bu demo kimlik doğrulama veya kullanıcı başına kota içermez. Worker URL'si herkese açık olursa başkaları da çağırabilir. Gerçek yayında hız sınırı / erişim kontrolü ekle.
- Gemini kota, erişim ve ücretlendirme koşulları Google hesabına ve modeline bağlıdır.
- Yapay zekâ “her soruya” cevap vermeyi garanti edemez; bazı istekleri reddedebilir, yanlış yanıt verebilir veya kota/bağlantı hatası alabilir.
